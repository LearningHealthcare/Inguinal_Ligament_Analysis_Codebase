# Dumbbell Plot Code Adaptation
# Code Citation
# Title: (ggplot2) Exercising with (ggalt) dumbbells
# Date: April 17, 2016
# Type: Code from Blog Post
# Availability: https://rud.is/b/2016/04/17/ggplot2-exercising-with-ggalt-dumbbells/

setwd(visualizations.directory)

vein.max.diameter.dumbbell.plot = ggplot() + geom_dumbbell(data = vein.max.diameter.dataframe, aes(y = Vein, x = Mean.Vein.Diameter.Before.Stenting, 
  xend = Mean.Vein.Diameter.After.Stenting), colour_x = "blue", colour_xend = "red", size_x = 3, size_xend = 3) + theme_minimal() + labs(x = "Vein Diameter",
  title = "Maximum Vein Diameter Before vs. After Stenting Plot by Vein") + theme(axis.title = element_text(size = 14), axis.text = element_text(size = 14), 
  plot.title = element_text(size = 16, hjust = 0.5)) + geom_text(data = filter(vein.max.diameter.dataframe, Vein =="LCIV"),
      aes(x = Mean.Vein.Diameter.Before.Stenting, y = Vein, label = "Vein Diameter Before Stenting"), color = "blue", size = 5, vjust = -2) + 
  geom_text(data = filter(vein.max.diameter.dataframe, Vein == "LCIV"),
            aes(x = Mean.Vein.Diameter.After.Stenting, y = Vein, label = "Vein Diameter After Stenting"),
            color= "red", size = 5, vjust = -2) + scale_x_continuous(limits = c(4, 12), breaks = seq(4, 12, 1)) +
  geom_text(data = vein.max.diameter.dataframe, aes(x = Mean.Vein.Diameter.Before.Stenting, y = Vein, label = Mean.Vein.Diameter.Before.Stenting),
            color= "blue", size = 5, vjust = 2.5) + geom_text(data = vein.max.diameter.dataframe, color = "red", size = 5, vjust = 2.5,
            aes(x = Mean.Vein.Diameter.After.Stenting, y = Vein, label = Mean.Vein.Diameter.After.Stenting))

# Dumbbell Plot Code Adaptation
# Code Citation
# Title: (ggplot2) Exercising with (ggalt) dumbbells
# Date: April 17, 2016
# Type: Code from Blog Post
# Availability: https://rud.is/b/2016/04/17/ggplot2-exercising-with-ggalt-dumbbells/

vein.min.diameter.dumbbell.plot = ggplot() + geom_dumbbell(data = vein.min.diameter.dataframe, aes(y = Vein, x = Mean.Vein.Diameter.Before.Stenting, 
  xend = Mean.Vein.Diameter.After.Stenting), colour_x = "blue", colour_xend = "red", size_x = 3, size_xend = 3) + theme_minimal() + labs(x = "Vein Diameter",
  title = "Minimum Vein Diameter Before vs. After Stenting Plot by Vein") + theme(axis.title = element_text(size = 14), axis.text = element_text(size = 12), 
  plot.title = element_text(size = 16, hjust = 0.5)) + geom_text(data = filter(vein.min.diameter.dataframe, Vein =="LCIV"),
            aes(x = Mean.Vein.Diameter.Before.Stenting, y = Vein, label = "Vein Diameter Before Stenting"), color = "blue", size = 5, vjust = -2) + 
  geom_text(data = filter(vein.min.diameter.dataframe, Vein == "LCIV"),
            aes(x = Mean.Vein.Diameter.After.Stenting, y = Vein, label = "Vein Diameter After Stenting"),
            color="red", size = 5, vjust = -2) + scale_x_continuous(limits = c(2, 10), breaks = seq(2, 10, 1)) +
  geom_text(data = vein.min.diameter.dataframe, aes(x = Mean.Vein.Diameter.Before.Stenting, y = Vein, label = Mean.Vein.Diameter.Before.Stenting),
            color="blue", size = 5, vjust = 2.5) + geom_text(data = vein.min.diameter.dataframe, color = "red", size = 5, vjust = 2.5,
                                                             aes(x = Mean.Vein.Diameter.After.Stenting, y = Vein, label = Mean.Vein.Diameter.After.Stenting))

# Dumbbell Plot Code Adaptation
# Code Citation
# Title: (ggplot2) Exercising with (ggalt) dumbbells
# Date: April 17, 2016
# Type: Code from Blog Post
# Availability: https://rud.is/b/2016/04/17/ggplot2-exercising-with-ggalt-dumbbells/

left.villalta.dumbbell.plot = ggplot() + geom_dumbbell(data = left.villalta.dataframe, aes(y = Left.Limb.Status, x = Mean.Villalta.Score.Pre.Stenting, 
  xend = Mean.Villalta.Score.Post.Stenting), colour_x = "blue", colour_xend = "red", size_x = 3, size_xend = 3) + theme_minimal() + labs(x = "Left Leg Villalta Score",
        title = "Left Leg Villalta Scores by Inguinal Ligament Status") + theme(axis.title = element_text(size = 14), axis.text = element_text(size = 12), 
  plot.title = element_text(size = 16, hjust = 0.5)) + geom_text(data = filter(left.villalta.dataframe, Left.Limb.Status =="Above.Inguinal.Ligament"),
            aes(x = Mean.Villalta.Score.Pre.Stenting, y = Left.Limb.Status, label = "Villalta Score Before Stenting"), color = "blue", size = 5, vjust = -2) + 
  geom_text(data = filter(left.villalta.dataframe, Left.Limb.Status == "Above.Inguinal.Ligament"),
            aes(x = Mean.Villalta.Score.Post.Stenting, y = Left.Limb.Status, label = "Villalta Score After Stenting"),
            color="red", size = 5, vjust = -2) + scale_x_continuous(limits = c(2, 20), breaks = seq(2, 20, 2)) +
  geom_text(data = left.villalta.dataframe, aes(x = Mean.Villalta.Score.Pre.Stenting, y = Left.Limb.Status, label = Mean.Villalta.Score.Pre.Stenting),
            color="blue", size = 5, vjust = 2.5) + geom_text(data = left.villalta.dataframe, color = "red", size = 5, vjust = 2.5,
            aes(x = Mean.Villalta.Score.Post.Stenting, y = Left.Limb.Status, label = Mean.Villalta.Score.Post.Stenting))

# Dumbbell Plot Code Adaptation
# Code Citation
# Title: (ggplot2) Exercising with (ggalt) dumbbells
# Date: April 17, 2016
# Type: Code from Blog Post
# Availability: https://rud.is/b/2016/04/17/ggplot2-exercising-with-ggalt-dumbbells/

right.villalta.dumbbell.plot = ggplot() + geom_dumbbell(data = right.villalta.dataframe, aes(y = Right.Limb.Status, x = Mean.Villalta.Score.Pre.Stenting, 
  xend = Mean.Villalta.Score.Post.Stenting), colour_x = "blue", colour_xend = "red", size_x = 3, size_xend = 3) + theme_minimal() + labs(x = "Right Leg Villalta Score",
  title = "Right Leg Villalta Scores by Inguinal Ligament Status") + theme(axis.title = element_text(size = 14), axis.text = element_text(size = 12), 
  plot.title = element_text(size = 16, hjust = 0.5)) + geom_text(data = filter(right.villalta.dataframe, Right.Limb.Status =="Above.Inguinal.Ligament"),
            aes(x = Mean.Villalta.Score.Pre.Stenting, y = Right.Limb.Status, label = "Villalta Score Before Stenting"), color = "blue", size = 5, vjust = -2) + 
  geom_text(data = filter(right.villalta.dataframe, Right.Limb.Status == "Above.Inguinal.Ligament"),
            aes(x = Mean.Villalta.Score.Post.Stenting, y = Right.Limb.Status, label = "Villalta Score After Stenting"),
            color="red", size = 5, vjust = -2) + scale_x_continuous(limits = c(2, 20), breaks = seq(2, 20, 2)) +
  geom_text(data = right.villalta.dataframe, aes(x = Mean.Villalta.Score.Pre.Stenting, y = Right.Limb.Status, label = Mean.Villalta.Score.Pre.Stenting),
            color="blue", size = 5, vjust = 2.5) + geom_text(data = right.villalta.dataframe, color = "red", size = 5, vjust = 2.5,
            aes(x = Mean.Villalta.Score.Post.Stenting, y = Right.Limb.Status, label = Mean.Villalta.Score.Post.Stenting))