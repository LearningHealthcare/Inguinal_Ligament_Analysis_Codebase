# vein_diameter_summary_statistics_plots.R

# This script calculates vein diameter summary statistics.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

vein.max.diameter.before.stenting = iliac.femoral.veins %>%
  select(record_id, Vein, Max.Diameter.Before.Stenting) %>%
  filter(!is.na(Max.Diameter.Before.Stenting))

# Mean Maximum Vein Diameter by Vein prior to stenting
vein.max.diameter.before.stenting.statistics.mean = iliac.femoral.veins %>%
  select(Vein, Max.Diameter.Before.Stenting) %>%
  filter(!is.na(Max.Diameter.Before.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Mean.Vein.Diameter.Before.Stenting = mean(Max.Diameter.Before.Stenting))

# Average Time that Vein Diameter Measurement occurs prior to stenting
vein.max.diameter.before.stenting.span.average = mean(iliac.femoral.veins$Max.Diameter.Before.Stenting.Span, na.rm = TRUE)

# Number of Maximum Vein Diameter Measurements by Vein prior to stenting
vein.max.diameter.before.stent.vein.count = iliac.femoral.veins %>%
  select(Vein, Max.Diameter.Before.Stenting) %>%
  filter(!is.na(Max.Diameter.Before.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Measurement.Count = n())

# Number of Maximum Vein Diameter Measurements prior to stenting
vein.max.diameter.before.stenting.count = nrow(filter(iliac.femoral.veins, !is.na(Max.Diameter.Before.Stenting)))

# Standard Deviation Maximum Vein Diameter by Vein prior to stenting
vein.max.diameter.before.stenting.sd = iliac.femoral.veins %>%
  select(Vein, Max.Diameter.Before.Stenting) %>%
  filter(!is.na(Max.Diameter.Before.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Standard.Deviation.Vein.Diameter = sd(Max.Diameter.Before.Stenting))

vein.max.diameter.after.stenting = iliac.femoral.veins %>%
  select(record_id, Vein, Max.Diameter.After.Stenting) %>%
  filter(!is.na(Max.Diameter.After.Stenting))

# Mean Maximum Vein Diameter by Vein after stenting
vein.max.diameter.after.stenting.statistics.mean = iliac.femoral.veins %>%
  select(Vein, Max.Diameter.After.Stenting) %>%
  filter(!is.na(Max.Diameter.After.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Mean.Vein.Diameter.After.Stenting = mean(Max.Diameter.After.Stenting))

# Number of Maximum Vein Diameter Measurements by Vein after stenting
vein.max.diameter.after.stent.vein.count = iliac.femoral.veins %>%
  select(Vein, Max.Diameter.After.Stenting) %>%
  filter(!is.na(Max.Diameter.After.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Measurement.Count = n())

# Average Time that Vein Diameter Measurement occurs after stenting
vein.max.diameter.after.stenting.span.average = mean(iliac.femoral.veins$Max.Diameter.After.Stenting.Span, na.rm = TRUE)

# Total Number of Vein Diameter Measurements after stenting 
vein.max.diameter.after.stenting.count = nrow(filter(iliac.femoral.veins, !is.na(Max.Diameter.After.Stenting)))

# Standard Deviation Maximum Vein Diameter by Vein post stenting
vein.max.diameter.after.stenting.sd = iliac.femoral.veins %>%
  select(Vein, Max.Diameter.After.Stenting) %>%
  filter(!is.na(Max.Diameter.After.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Standard.Deviation.Vein.Diameter = sd(Max.Diameter.After.Stenting))

vein.list = c("RFEMV","RCFV", "REIV", "RCIV","LFEMV", "LCFV", "LEIV", "LCIV")

# Average Maximum Vein Diameter dataframe, pre and post stenting, by Vein
vein.max.diameter.dataframe = inner_join(vein.max.diameter.after.stenting.statistics.mean, vein.max.diameter.before.stenting.statistics.mean,
                                         by = c("Vein"))

vein.max.diameter.dataframe$Vein = factor(vein.max.diameter.dataframe$Vein, 
  levels = vein.list)

vein.max.diameter.dataframe$Mean.Vein.Diameter.After.Stenting = round(vein.max.diameter.dataframe$Mean.Vein.Diameter.After.Stenting, digits = 1)

vein.max.diameter.dataframe$Mean.Vein.Diameter.Before.Stenting = round(vein.max.diameter.dataframe$Mean.Vein.Diameter.Before.Stenting, digits = 1)

vein.max.diameter.stenting.dataframe = vein.max.diameter.before.stenting %>%
  inner_join(vein.max.diameter.after.stenting, by = c("record_id", "Vein")) %>%
  filter(!is.na(Max.Diameter.Before.Stenting) & !is.na(Max.Diameter.After.Stenting))

vein.min.diameter.before.stenting = iliac.femoral.veins %>%
  select(record_id, Vein, Min.Diameter.Before.Stenting) %>%
  filter(!is.na(Min.Diameter.Before.Stenting))

# Mean Minimum Vein Diameter by Vein prior to stenting
vein.min.diameter.before.stenting.statistics.mean = iliac.femoral.veins %>%
  select(Vein, Min.Diameter.Before.Stenting) %>%
  filter(!is.na(Min.Diameter.Before.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Mean.Vein.Diameter.Before.Stenting = mean(Min.Diameter.Before.Stenting))

# Average Time that Vein Diameter Measurement occurs prior to stenting
vein.min.diameter.before.stenting.span.average = mean(iliac.femoral.veins$Min.Diameter.Before.Stenting.Span, na.rm = TRUE)

# Number of Minimum Vein Diameter Measurements by Vein prior to Stenting
vein.min.diameter.before.vein.count = iliac.femoral.veins %>%
  select(Vein, Min.Diameter.Before.Stenting) %>%
  filter(!is.na(Min.Diameter.Before.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Measurement.Count = n())

# Number of Minimum Vein Diameter Measurements prior to stenting
vein.min.diameter.before.stenting.count = nrow(filter(iliac.femoral.veins, !is.na(Min.Diameter.Before.Stenting)))

# Standard Deviation Minimum Vein Diameter by Vein prior to stenting
vein.min.diameter.before.stenting.sd = iliac.femoral.veins %>%
  select(Vein, Min.Diameter.Before.Stenting) %>%
  filter(!is.na(Min.Diameter.Before.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Standard.Deviation.Vein.Diameter = sd(Min.Diameter.Before.Stenting))

vein.min.diameter.after.stenting = iliac.femoral.veins %>%
  select(record_id, Vein, Min.Diameter.After.Stenting) %>%
  filter(!is.na(Min.Diameter.After.Stenting))

# Mean Minimum Vein Diameter by Vein after stenting
vein.min.diameter.after.stenting.statistics.mean = iliac.femoral.veins %>%
  select(Vein, Min.Diameter.After.Stenting) %>%
  filter(!is.na(Min.Diameter.After.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Mean.Vein.Diameter.After.Stenting = mean(Min.Diameter.After.Stenting))

# Number of Minimum Vein Diameter Measurements by Vein after stenting
vein.min.diameter.after.vein.count = iliac.femoral.veins %>%
  select(Vein, Min.Diameter.After.Stenting) %>%
  filter(!is.na(Min.Diameter.After.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Measurement.Count = n())

# Average Time that Vein Diameter Measurement occurs after stenting
vein.min.diameter.after.stenting.span.average = mean(iliac.femoral.veins$Min.Diameter.After.Stenting.Span, na.rm = TRUE)

# Total Number of Vein Diameter Measurements after stenting
vein.min.diameter.after.stenting.count = nrow(filter(iliac.femoral.veins, !is.na(Min.Diameter.After.Stenting)))

# Standard Deviation Maximum Vein Diameter by Vein post stenting
vein.min.diameter.after.stenting.sd = iliac.femoral.veins %>%
  select(Vein, Min.Diameter.After.Stenting) %>%
  filter(!is.na(Min.Diameter.After.Stenting)) %>%
  group_by(Vein) %>%
  summarise(Standard.Deviation.Vein.Diameter = sd(Max.Diameter.After.Stenting))

# Average Minimum Vein Diameter dataframe, pre and post stenting, by Vein
vein.min.diameter.dataframe = inner_join(vein.min.diameter.after.stenting.statistics.mean, vein.min.diameter.before.stenting.statistics.mean,
                                         by = c("Vein"))

vein.min.diameter.dataframe$Vein = factor(vein.min.diameter.dataframe$Vein, 
                                          levels = vein.list)

vein.min.diameter.dataframe$Mean.Vein.Diameter.After.Stenting = round(vein.min.diameter.dataframe$Mean.Vein.Diameter.After.Stenting, digits = 1)

vein.min.diameter.dataframe$Mean.Vein.Diameter.Before.Stenting = round(vein.min.diameter.dataframe$Mean.Vein.Diameter.Before.Stenting, digits = 1)

vein.min.diameter.stenting.dataframe = vein.min.diameter.before.stenting %>%
  inner_join(vein.min.diameter.after.stenting, by = c("record_id", "Vein")) %>%
  filter(!is.na(Min.Diameter.Before.Stenting) & !is.na(Min.Diameter.After.Stenting))