# complications_summary_statistics.R

# This script calculates complication summary statistics for the analysis cohort.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

intra.procedural.complications = inguinal.ligament.data.frame %>%
  select(record_id, Procedure.Number) %>%
  inner_join(procedure.complications.data, by = c("record_id", "Procedure.Number"))

# Intra-procedural Complications by Major/Minor Status
intra.procedural.complications.summary.statistics = intra.procedural.complications %>%
  group_by(Complication.Major.Minor.Status) %>%
  summarise(Complication.Count = n())

source(paste(results.code.directory, 'bleeding_complication_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'other_complication_summary_statistics.R', sep = '/'))

# IR Clinic Visit Thrombotic Complications
ir.thrombotic.complication.count = inguinal.ligament.data.frame %>%
  select(record_id, ir.clinic.visit.first.thrombotic.complication.name, ir.clinic.visit.first.thrombotic.complication.time,
         ir.clinic.visit.first.thrombotic.complication.date, Followup.Start.Date, primary.patency.left.leg.span, primary.patency.right.leg.span) %>%
  filter(!is.na(ir.clinic.visit.first.thrombotic.complication.date) & !is.na(ir.clinic.visit.first.thrombotic.complication.name)) %>%
  # Span between Thrombotic Complication Date and follow-up start date (Stent Placement Date)
  mutate(IR.Visit.Thrombotic.Complication.Span = round(as.numeric(as.Date(ir.clinic.visit.first.thrombotic.complication.date), Followup.Start.Date, units = "days"), digits = 0)) %>%
  # Thrombotic Complications within year of Stent Placement Date
  filter(IR.Visit.Thrombotic.Complication.Span < 365.25) %>%
  filter(is.na(primary.patency.left.leg.span) | IR.Visit.Thrombotic.Complication.Span <= primary.patency.left.leg.span) %>%
  filter(is.na(primary.patency.right.leg.span) | IR.Visit.Thrombotic.Complication.Span <= primary.patency.right.leg.span)

# Non-IR Encounter Thrombotic Complications
non.ir.thrombotic.complication.count = inguinal.ligament.data.frame %>%
  select(record_id, non.ir.clinic.encounter.first.thrombotic.complication.name, non.ir.clinic.encounter.first.thrombotic.complication.time,
         non.ir.clinic.encounter.first.thrombotic.complication.date, Followup.Start.Date, primary.patency.left.leg.span, primary.patency.right.leg.span) %>%
  filter(!is.na(non.ir.clinic.encounter.first.thrombotic.complication.date) & !is.na(non.ir.clinic.encounter.first.thrombotic.complication.name)) %>%
  mutate(Non.IR.Encounter.Thrombotic.Complication.Span = round(as.numeric(difftime(as.Date(non.ir.clinic.encounter.first.thrombotic.complication.date), Followup.Start.Date, units = "days")), digits = 0)) %>%
  # Thrombotic Complications within year of Stent Placement Date
  filter(Non.IR.Encounter.Thrombotic.Complication.Span < 365.25) %>%
  filter(is.na(primary.patency.left.leg.span) | Non.IR.Encounter.Thrombotic.Complication.Span <= primary.patency.left.leg.span) %>%
  filter(is.na(primary.patency.right.leg.span) | Non.IR.Encounter.Thrombotic.Complication.Span <= primary.patency.right.leg.span)

thrombotic.complication.patients = unique(c(ir.thrombotic.complication.count$record_id, non.ir.thrombotic.complication.count$record_id))

# Number of patients with major thrombotic complications
thrombotic.complication.count = length(thrombotic.complication.patients)

thrombotic.complication.patients = data.frame(thrombotic.complication.patients)

names(thrombotic.complication.patients) = "record_id"

thrombotic.complication.patients = ir.thrombotic.complication.count %>%
  select(-primary.patency.left.leg.span, -primary.patency.right.leg.span, -Followup.Start.Date) %>%
  right_join(thrombotic.complication.patients, by = "record_id")

thrombotic.complication.patients = non.ir.thrombotic.complication.count %>%
  select(-primary.patency.left.leg.span, -primary.patency.right.leg.span, -Followup.Start.Date) %>%
  right_join(thrombotic.complication.patients, by = "record_id")

# Combined Thrombotic complication statistics by complication name
total.thrombotic.complication.name.summary.statistics = thrombotic.complication.patients %>%
  select(record_id, non.ir.clinic.encounter.first.thrombotic.complication.name, ir.clinic.visit.first.thrombotic.complication.name) %>%
  gather(Encounter.Type, Complication.Status, -record_id) %>%
  filter(!is.na(Complication.Status)) %>%
  group_by(Complication.Status) %>%
  summarise(Complication.Count = n())

# Combined Thrombotic complication statistics by complication time
total.thrombotic.complication.time.summary.statistics = thrombotic.complication.patients %>%
  select(record_id, non.ir.clinic.encounter.first.thrombotic.complication.time, ir.clinic.visit.first.thrombotic.complication.time) %>%
  gather(Encounter.Type, Complication.Time, -record_id) %>%
  filter(!is.na(Complication.Time)) %>%
  group_by(Complication.Time) %>%
  summarise(Complication.Count = n()) %>%
  arrange(desc(Complication.Count))