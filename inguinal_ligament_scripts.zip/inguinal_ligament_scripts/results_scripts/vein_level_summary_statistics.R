# vein_level_summary_statistics.R

# This script is responsible for calculating most vein-level summary statistics.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Number of stented veins in cohort
num.stented.veins = nrow(inguinal.ligament.stented.vein.cohort)

# Identify stented iliac and femoral veins
iliac.femoral.veins = inguinal.ligament.stented.vein.cohort %>%
  filter(Vein == "LCIV" | Vein == "LEIV" | Vein == "LCFV" | Vein == "LFEMV" |
  Vein == "RCIV" | Vein == "REIV" | Vein == "RCFV" | Vein == "RFEMV") %>%
  mutate(Iliac.Femoral.Vein.Status = ifelse(Vein == "LCIV" | Vein == "LEIV" | 
        Vein == "RCIV" | Vein == "REIV", "Iliac", "Femoral")) %>%
  mutate(Restenosis.Status = ifelse(!is.na(First.Restenosis.Date), "Restenosis", "No Restenosis"))

# Number of Iliac and Femoral Stented Veins in cohort
num.stented.iliac.femoral.veins = nrow(iliac.femoral.veins)

# Number of Stented Veins by Iliac/Femoral Vein Status
iliac.femoral.summary.statistics = iliac.femoral.veins %>%
  group_by(Iliac.Femoral.Vein.Status) %>%
  summarise(Vein.Count = n())

# Number of Iliac/Femoral Veins that developed in-stent restenosis
num.veins.restenosis = nrow(filter(iliac.femoral.veins,
  Restenosis.Status == "Restenosis"))

# Restenosis statistics by Iliac/Femoral Vein Status
iliac.femoral.restenosis.summary.statistics = iliac.femoral.veins %>%
  group_by(Iliac.Femoral.Vein.Status, Restenosis.Status) %>%
  summarise(Restenosis.Status.Count = n()) %>%
  inner_join(iliac.femoral.summary.statistics, by = "Iliac.Femoral.Vein.Status") %>%
  mutate(Percentage.Vein.Cohort = Restenosis.Status.Count / Vein.Count) 

# Number of patients considered in vein-level analysis
iliac.femoral.vein.patient.count = iliac.femoral.veins %>%
  select(record_id) %>%
  unique()

iliac.femoral.vein.patient.count = nrow(iliac.femoral.vein.patient.count)

# Number of limbs considered in vein-level analysis
iliac.femoral.limb.patient.count = iliac.femoral.veins %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status) %>%
  gather(Limb, Limb.Status, -record_id) %>%
  filter(!is.na(Limb.Status)) %>%
  unique()

iliac.femoral.limb.patient.count = nrow(iliac.femoral.limb.patient.count)