# risk_factors_summary_statistics.R

# This script calculates risk factor related summary statistics for the analysis
# cohort.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Number of patients by IVC Status
patient.ivc.status.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, IVC.Status) %>%
  group_by(IVC.Status) %>%
  summarise(Cohort.Count = n())

# Limb-Level IVC Status versus Inguinal Ligament Summary Statistics
limb.ivc.status.inguinal.ligament.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, IVC.Status) %>%
  gather(Limb, Limb.Status, -record_id, -IVC.Status) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb.Status, IVC.Status) %>%
  summarise(Cohort.count = n()) %>%
  spread(IVC.Status, Cohort.count)

# Number of Patients by Thrombophilia Status
patient.thrombophilia.status = inguinal.ligament.data.frame %>%
  select(record_id, Thrombophilia.Risk.Factor.Status) %>%
  group_by(Thrombophilia.Risk.Factor.Status) %>%
  summarise(Cohort.Count = n())

# Limb Level DVT/Lymphedema Status versus Inguinal Ligament Summary Statistics
limb.dvt.lymphedema.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Leg.DVT.Lymphedema.Status, Right.Leg.DVT.Lymphedema.Status) %>%
  gather(Limb, Limb.Status, -record_id) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb.Status) %>%
  summarise(Cohort.Count = n()) %>%
  arrange(desc(Cohort.Count))

# Left Limb DVT/Lymphedema Status versus Inguinal Ligament Summary Statistics
left.limb.inguinal.dvt.lymphedema.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Left.Leg.DVT.Lymphedema.Status) %>%
  filter(!is.na(Left.Limb.Status)) %>%
  unique() %>%
  group_by(Left.Limb.Status, Left.Leg.DVT.Lymphedema.Status) %>%
  summarise(Cohort.Count = n()) %>%
  arrange(desc(Cohort.Count))

# Right Limb DVT/Lymphedema versus Inguinal Ligament Summary Statistics
right.limb.inguinal.dvt.lymphedema.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Right.Limb.Status, Right.Leg.DVT.Lymphedema.Status) %>%
  filter(!is.na(Right.Limb.Status)) %>%
  unique() %>%
  group_by(Right.Limb.Status, Right.Leg.DVT.Lymphedema.Status) %>%
  summarise(Cohort.Count = n()) %>%
  arrange(desc(Cohort.Count))