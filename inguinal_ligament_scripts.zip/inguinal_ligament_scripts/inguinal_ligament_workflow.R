# inguinal_ligament_workflow.R

# This overarching script performs all analyses related to the study
# of lower extremity vein stenting, particularly the question of inguinal 
# ligament stenting.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# R libraries used in data analysis scripts
library(ggplot2)
library(ggalt)
library(survival)
library(survminer)
library(ggpubr)

# Data Analysis Paths to Code Directories
pre.processing.code.directory = ''
results.code.directory = ''
cohort.selection.code.directory = ''
feature.calculation.code.directory = ''
patency.calculation.code.directory = ''
visualizations.directory = ''

source(paste(pre.processing.code.directory, 'VITAL_pre_processing.R', sep = '/'))

source(paste(cohort.selection.code.directory, 'determine_first_Stanford_stenting_procedure.R', sep = '/'))

source(paste(cohort.selection.code.directory, 'exclude_outside_venous_stenting_patients.R', sep = '/'))

source(paste(cohort.selection.code.directory, 'examine_prior_imaging.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_ivc_stenting_patients.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_end_of_follow_up.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_inguinal_ligament_status.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'patency_rate_module.R', sep = '/'))

inguinal.ligament.data.frame = patency.rate.dataframe

source(paste(feature.calculation.code.directory, 'determine_in_stent_restenosis_status.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'vein_diameter_module.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_villata_score_changes.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_covariates_status.R', sep = '/'))

source(paste(results.code.directory, 'summary_statistics_module.R', sep = '/'))

source(paste(results.code.directory, 'statistical_test_module.R', sep = '/'))

source(paste(results.code.directory, 'visualizations_module.R', sep = '/'))

source(paste(results.code.directory, 'kaplan_meier_module.R', sep = '/'))

source(paste(results.code.directory, 'cox_proportional_hazard_module.R', sep = '/'))
