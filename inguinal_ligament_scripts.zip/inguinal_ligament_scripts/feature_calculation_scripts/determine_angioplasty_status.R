# determine_angioplasty_status.R

# This script determines if/how angioplasty was used during the same procedure
# as the procedure that resulted in the placement of stents (stent placement date/First Stanford procedure date).
# More specifically, this script calculates if standalone angioplasty, stent angioplasty, no angioplasty,
# or both types of angioplasty were used.

Angioplasty.Status = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

# Dataframe containing stent angioplasty procedure data
stent.angioplasty.procedure.data = gather(stent.angioplasty.procedure.data,
      stent.number, Plasty.Status, -record_id, -Procedure.Number)

stent.angioplasty.procedure.data$Plasty.Status = as.character(stent.angioplasty.procedure.data$Plasty.Status)

stent.angioplasty.procedure.data = stent.angioplasty.procedure.data %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Stent.Number = gsub("[^0-9]", "", stent.number)) %>%
  select(-stent.number) %>%
  filter(Plasty.Status == "Yes")

stent.angioplasty.procedure.data = stent.location.procedure.data %>%
  select(record_id, Procedure.Number, Stent.Number, Vein) %>%
  right_join(stent.angioplasty.procedure.data, by = c("record_id", "Procedure.Number", "Stent.Number"))

for(i in 1:nrow(inguinal.ligament.stented.vein.cohort)){
  stent.patient = inguinal.ligament.stented.vein.cohort$record_id[i]
  stent.vein = inguinal.ligament.stented.vein.cohort$Vein[i]
  procedure.number = inguinal.ligament.stented.vein.cohort$Procedure.Number[i]
  # standalone angioplasty by patient, Vein, and procedure
  standalone.plasty.data = standalone.angioplasty.location.procedure.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stent.vein) %>%
    filter(Procedure.Number == procedure.number)
  if(nrow(standalone.plasty.data) > 0){
    Angioplasty.Status[i] = "Standalone.Angioplasty"
  }
  # stent angioplasty by patient, Vein, and procedure
  stent.angioplasty.data = stent.angioplasty.procedure.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stent.vein) %>%
    filter(Procedure.Number == procedure.number)
  if(nrow(stent.angioplasty.data) > 0){
    if(!is.na(Angioplasty.Status[i])){
      Angioplasty.Status[i] = "Both"
    }else{
      Angioplasty.Status[i] = "Stent.Angioplasty"
    }
  }
}

inguinal.ligament.stented.vein.cohort = cbind.data.frame(inguinal.ligament.stented.vein.cohort,
  Angioplasty.Status)