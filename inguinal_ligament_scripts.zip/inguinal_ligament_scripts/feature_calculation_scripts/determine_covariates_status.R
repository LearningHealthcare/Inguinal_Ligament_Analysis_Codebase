# determine_covariates_status.R

# This script calculates both vein and limb level covariates to be used in subsequent analyses.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(feature.calculation.code.directory, 'determine_vein_level_covariates.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_limb_level_covariates.R', sep = '/'))