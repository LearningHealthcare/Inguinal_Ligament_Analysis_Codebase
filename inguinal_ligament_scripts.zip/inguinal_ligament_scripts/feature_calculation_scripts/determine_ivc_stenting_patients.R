# determine_ivc_stenting_patients.R

# This script determines, for each remaining patient in the analysis, whether
# IVC stenting was performed on the same day as the first Stanford Procedure Date.

# Dataframe for patients with IVC stenting on first Stanford Procedure Date
first.Stanford.procedure.ivc.patients = first.Stanford.procedure.dataframe %>%
  left_join(stent.location.procedure.data, by = c("record_id", "Procedure.Number")) %>%
  filter(Vein == "Suprarenal.IVC" | Vein == "Infrarenal.IVC") %>%
  select(record_id) %>%
  unique()

first.Stanford.procedure.ivc.patients = first.Stanford.procedure.ivc.patients[, 1]

first.Stanford.procedure.dataframe = mutate(first.Stanford.procedure.dataframe, 
  IVC.Status = ifelse(record_id %in% first.Stanford.procedure.ivc.patients, "Yes", "No"))
