# determine_inguinal_ligament_status.R

# This script is responsible for determining whether a patient has 
# stenting above versus below the inguinal ligament by limb, as well as
# their illiac/femoral/iliofemoral vein stenting status by limb.

# By David Cohn

# Rubin and Hofmann Lab, July 2018

inguinal.ligament.patients = first.Stanford.procedure.dataframe$record_id

Left.Limb.Inguinal.Ligament.Status = rep(NA, times = nrow(first.Stanford.procedure.dataframe))

Right.Limb.Inguinal.Ligament.Status = rep(NA, times = nrow(first.Stanford.procedure.dataframe))

Left.Limb.Iliofemoral.Status = rep(NA, times = nrow(first.Stanford.procedure.dataframe))

Right.Limb.Iliofemoral.Status = rep(NA, times = nrow(first.Stanford.procedure.dataframe))

# Inguinal Ligament and Iliac/Femoral/Iliofemoral Calculations by patient
for(i in 1:length(inguinal.ligament.patients)){
  inguinal.ligament.patient = inguinal.ligament.patients[i]
  record.id.stent.location.data = first.Stanford.procedure.dataframe %>%
    left_join(stent.location.procedure.data, by = c("record_id", "Procedure.Number")) %>%
    filter(record_id == inguinal.ligament.patient) %>%
    select(Vein) %>%
    unique()
  if(nrow(record.id.stent.location.data) > 0){
    record.id.stent.location.data = record.id.stent.location.data$Vein
      if("LCIV" %in% record.id.stent.location.data | "LEIV" %in% record.id.stent.location.data){
        Left.Limb.Inguinal.Ligament.Status[i] = "Above.Inguinal.Ligament"
        Left.Limb.Iliofemoral.Status[i] = "Iliac" 
      }
      if("LCFV" %in% record.id.stent.location.data | "LFEMV" %in% record.id.stent.location.data | 
         "LPOP" %in% record.id.stent.location.data | "LPFV" %in% record.id.stent.location.data){
        Left.Limb.Inguinal.Ligament.Status[i] = "Below.Inguinal.Ligament"
        if(!is.na(Left.Limb.Iliofemoral.Status[i]) & ("LCFV" %in% record.id.stent.location.data | 
            "LFEMV" %in% record.id.stent.location.data)){
          Left.Limb.Iliofemoral.Status[i] = "Iliofemoral"
        }else if(is.na(Left.Limb.Iliofemoral.Status[i]) & ("LCFV" %in% record.id.stent.location.data | 
            "LFEMV" %in% record.id.stent.location.data)){
          Left.Limb.Iliofemoral.Status[i] = "Femoral"
        }
      }
    if("RCIV" %in% record.id.stent.location.data | "REIV" %in% record.id.stent.location.data){
      Right.Limb.Inguinal.Ligament.Status[i] = "Above.Inguinal.Ligament"
      Right.Limb.Iliofemoral.Status[i] = "Iliac" 
    }
    if("RCFV" %in% record.id.stent.location.data | "RFEMV" %in% record.id.stent.location.data | 
       "RPFV" %in% record.id.stent.location.data | "RPOP" %in% record.id.stent.location.data){
      Right.Limb.Inguinal.Ligament.Status[i] = "Below.Inguinal.Ligament"
      if(!is.na(Right.Limb.Iliofemoral.Status[i]) & ("RCFV" %in% record.id.stent.location.data | 
                                                       "RFEMV" %in% record.id.stent.location.data)){
        Right.Limb.Iliofemoral.Status[i] = "Iliofemoral"
      }else if(is.na(Right.Limb.Iliofemoral.Status[i]) & ("RCFV" %in% record.id.stent.location.data | 
                                                          "RFEMV" %in% record.id.stent.location.data)){
        Right.Limb.Iliofemoral.Status[i] = "Femoral"
      }
    }
  }
}

first.Stanford.procedure.dataframe = cbind.data.frame(first.Stanford.procedure.dataframe, Left.Limb.Inguinal.Ligament.Status,
                                                      Right.Limb.Inguinal.Ligament.Status, Left.Limb.Iliofemoral.Status,
                                                      Right.Limb.Iliofemoral.Status)

# Dataframe storing Limb/Patient Level data on patients considered in subsequent analyses
inguinal.ligament.data.frame = first.Stanford.procedure.dataframe %>%
  filter(!is.na(Left.Limb.Inguinal.Ligament.Status) | !is.na(Right.Limb.Inguinal.Ligament.Status)) %>%
  # Remove patients with IVC stenting and either left or right limb femoral stenting (no iliac stenting)
  filter(!(IVC.Status == "Yes" & (Left.Limb.Iliofemoral.Status == "Femoral" | Right.Limb.Iliofemoral.Status == "Femoral")))

# List of patients considered for subsequent analysis
inguinal.ligament.patients = inguinal.ligament.data.frame %>%
  select(record_id) %>%
  unique()

inguinal.ligament.patients = inguinal.ligament.patients[, 1]

patency.rate.dataframe = inguinal.ligament.data.frame

patency.rate.dataframe$Followup.Start.Date = patency.rate.dataframe$First.Stanford.Procedure.Date

patency.rate.dataframe$Left.Limb.Status = patency.rate.dataframe$Left.Limb.Inguinal.Ligament.Status

patency.rate.dataframe$Right.Limb.Status = patency.rate.dataframe$Right.Limb.Inguinal.Ligament.Status

patency.rate.dataframe = patency.rate.dataframe %>%
 # Left Leg Starting Patency Status
 mutate(Follow.Start.Left.Leg.Patency.Status = "Primary.Patency") %>%
 # Right Leg Starting Patency Status
 mutate(Follow.Start.Right.Leg.Patency.Status = "Primary.Patency") %>%
 select(-First.Stanford.Procedure.Date, -Left.Limb.Inguinal.Ligament.Status,
        -Right.Limb.Inguinal.Ligament.Status)

# cohort of stented veins considered in subsequent analyses
inguinal.ligament.stented.vein.cohort = first.Stanford.procedure.stent.locations %>%
  select(record_id, Procedure.Number, First.Stanford.Procedure.Date, Vein) %>%
  filter(record_id %in% inguinal.ligament.patients)

names(inguinal.ligament.stented.vein.cohort)[3] = "Stent.Placement.Date"
