# determine_villata_score_changes.R

# This script calculates left and right lower extremity Villalta Scores both before
# and after the stent placement date/first Stanford procedure date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

Left.Villalta.Score.Prior.Stenting = rep(NA, times = nrow(inguinal.ligament.data.frame))
Left.Villalta.Score.Prior.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.data.frame))
Left.Villalta.Score.Post.Stenting = rep(NA, times = nrow(inguinal.ligament.data.frame))
Left.Villalta.Score.Post.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.data.frame))
Right.Villalta.Score.Prior.Stenting = rep(NA, times = nrow(inguinal.ligament.data.frame))
Right.Villalta.Score.Prior.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.data.frame))
Right.Villalta.Score.Post.Stenting = rep(NA, times = nrow(inguinal.ligament.data.frame))
Right.Villalta.Score.Post.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.data.frame))

# Dataframe storing left lower extremity villalta data
left.villalta.clinic.visit.data = ir.clinic.visit.practitioner.visit.date.data %>%
  select(-practitioner) %>%
  right_join(left.villalta.clinic.visit.data, by = c("record_id", "IR.Clinic.Visit.Number"))

# Dataframe storing right lower extremity villalta data
right.villalta.clinic.visit.data = ir.clinic.visit.practitioner.visit.date.data %>%
  select(-practitioner) %>%
  right_join(right.villalta.clinic.visit.data, by = c("record_id", "IR.Clinic.Visit.Number"))

inguinal.ligament.data.frame$left.leg.reintervention.date = as.character(inguinal.ligament.data.frame$left.leg.primary.patency.loss.date)
inguinal.ligament.data.frame$right.leg.reintervention.date = as.character(inguinal.ligament.data.frame$right.leg.primary.patency.loss.date)

for(i in 1:nrow(inguinal.ligament.data.frame)){
  stenting.patient = inguinal.ligament.data.frame$record_id[i]
  follow.up.start.date = inguinal.ligament.data.frame$Followup.Start.Date[i]
  # Left Leg Villalta Calculations
  if(!is.na(inguinal.ligament.data.frame$Left.Limb.Status[i])){
    patient.villalta.data = left.villalta.clinic.visit.data %>%
      filter(record_id == stenting.patient) %>%
      # Span between Villalta Measurement and Stent Placement Date (Follow-up Start Date)
      mutate(Villalta.Measurement.Followup.Span = round(as.numeric(difftime(visitdate, 
            follow.up.start.date, units = "days")), digits = 0))
    patient.villalta.pre.stenting.data = patient.villalta.data %>%
      filter(Villalta.Measurement.Followup.Span < 0) %>%
      filter(Villalta.Measurement.Followup.Span > -imaging.window) %>%
      arrange(desc(visitdate))
    if(nrow(patient.villalta.pre.stenting.data) > 0){
      Left.Villalta.Score.Prior.Stenting[i] = patient.villalta.pre.stenting.data$l_villalta_calculated[1]
      Left.Villalta.Score.Prior.Stenting.Span[i] = patient.villalta.pre.stenting.data$Villalta.Measurement.Followup.Span[1]
    }
    patient.villalta.post.stenting.data = patient.villalta.data %>%
      filter(Villalta.Measurement.Followup.Span > 0) %>%
      filter(Villalta.Measurement.Followup.Span < imaging.window) %>%
      arrange(visitdate)
    # Ensure Left Leg Villalta Score occurred prior to any left leg re-intervention
    if(!is.na(inguinal.ligament.data.frame$left.leg.primary.patency.loss.date[i])){
      left.leg.reintervention.date = as.Date(inguinal.ligament.data.frame$left.leg.primary.patency.loss.date[i])
      patient.villalta.post.stenting.data = patient.villalta.post.stenting.data %>%
        mutate(Villalta.Measurement.Reintervention.Span = round(as.numeric(difftime(visitdate, 
              left.leg.reintervention.date, units = "days")), digits = 0)) %>%
        filter(Villalta.Measurement.Reintervention.Span < 0) %>%
        arrange(visitdate)
    }
    if(nrow(patient.villalta.post.stenting.data) > 0){
      Left.Villalta.Score.Post.Stenting[i] = patient.villalta.post.stenting.data$l_villalta_calculated[1]
      Left.Villalta.Score.Post.Stenting.Span[i] = patient.villalta.post.stenting.data$Villalta.Measurement.Followup.Span[1]
    }
  }
  # Right Leg Villalta Calculations
  if(!is.na(inguinal.ligament.data.frame$Right.Limb.Status[i])){
    patient.villalta.data = right.villalta.clinic.visit.data %>%
      filter(record_id == stenting.patient) %>%
      # Span between Villalta Measurement and Stent Placement Date (Follow-up Start Date)
      mutate(Villalta.Measurement.Followup.Span = round(as.numeric(difftime(visitdate, 
                    follow.up.start.date, units = "days")), digits = 0))
    patient.villalta.pre.stenting.data = patient.villalta.data %>%
      filter(Villalta.Measurement.Followup.Span < 0) %>%
      filter(Villalta.Measurement.Followup.Span > -imaging.window) %>%
      arrange(desc(visitdate))
    if(nrow(patient.villalta.pre.stenting.data) > 0){
      Right.Villalta.Score.Prior.Stenting[i] = patient.villalta.pre.stenting.data$r_villalta_calc[1]
      Right.Villalta.Score.Prior.Stenting.Span[i] = patient.villalta.pre.stenting.data$Villalta.Measurement.Followup.Span[1]
    }
    patient.villalta.post.stenting.data = patient.villalta.data %>%
      filter(Villalta.Measurement.Followup.Span > 0) %>%
      filter(Villalta.Measurement.Followup.Span < imaging.window) %>%
      arrange(visitdate)
    # Ensure Right Leg Villalta Score occurred prior to any right leg re-intervention
    if(!is.na(inguinal.ligament.data.frame$right.leg.primary.patency.loss.date[i])){
      right.leg.reintervention.date = as.Date(inguinal.ligament.data.frame$right.leg.primary.patency.loss.date[i])
      patient.villalta.post.stenting.data = patient.villalta.post.stenting.data %>%
        mutate(Villalta.Measurement.Reintervention.Span = round(as.numeric(difftime(visitdate, 
              right.leg.reintervention.date, units = "days")), digits = 0)) %>%
        filter(Villalta.Measurement.Reintervention.Span < 0) %>%
        arrange(visitdate)
    }
    if(nrow(patient.villalta.post.stenting.data) > 0){
      Right.Villalta.Score.Post.Stenting[i] = patient.villalta.post.stenting.data$r_villalta_calc[1]
      Right.Villalta.Score.Post.Stenting.Span[i] = patient.villalta.post.stenting.data$Villalta.Measurement.Followup.Span[1]
    }
  }
}

inguinal.ligament.data.frame = cbind.data.frame(inguinal.ligament.data.frame, Left.Villalta.Score.Prior.Stenting, 
    Left.Villalta.Score.Post.Stenting, Right.Villalta.Score.Prior.Stenting, Right.Villalta.Score.Post.Stenting,
    Left.Villalta.Score.Prior.Stenting.Span, Left.Villalta.Score.Post.Stenting.Span, Right.Villalta.Score.Prior.Stenting.Span,
    Right.Villalta.Score.Post.Stenting.Span)