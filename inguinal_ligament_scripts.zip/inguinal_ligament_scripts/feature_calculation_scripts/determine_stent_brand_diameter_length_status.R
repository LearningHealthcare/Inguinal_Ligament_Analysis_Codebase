# determine_stent_brand_diameter_length_status.R

# This script calculates the stent brand, diameter and length data used
# during stent placement.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

Stent.Brand = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

Stent.Diameter = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

Stent.Length = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

# Dataframe containing stent brand data
stent.brand.procedure.data = stent.brand.procedure.data %>%
  mutate(stent.number = Stent.Number) %>%
  select(-Stent.Number) %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Stent.Number = gsub("[^0-9]", "", stent.number)) %>%
  select(-stent.number)

# Dataframe containing stent diameter data
stent.diameter.procedure.data = stent.diameter.procedure.data %>%
  mutate(stent.number = Stent.Number) %>%
  select(-Stent.Number) %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Stent.Number = gsub("[^0-9]", "", stent.number)) %>%
  select(-stent.number)

# Dataframe containing stent length data
stent.length.procedure.data = stent.length.procedure.data %>%
  mutate(stent.number = Stent.Number) %>%
  select(-Stent.Number) %>%
  mutate(Stent.Number = gsub("[^0-9]", "", stent.number)) %>%
  select(-stent.number)

stent.diameter.procedure.data = stent.location.procedure.data %>%
  select(record_id, Procedure.Number, Stent.Number, Vein) %>%
  right_join(stent.diameter.procedure.data, by = c("record_id", "Procedure.Number", "Stent.Number"))

stent.brand.procedure.data = stent.location.procedure.data %>%
  select(record_id, Procedure.Number, Stent.Number, Vein) %>%
  right_join(stent.brand.procedure.data, by = c("record_id", "Procedure.Number", "Stent.Number"))

stent.length.procedure.data = stent.location.procedure.data %>%
  select(record_id, Procedure.Number, Stent.Number, Vein) %>%
  right_join(stent.length.procedure.data, by = c("record_id", "Procedure.Number", "Stent.Number"))

for(i in 1:nrow(inguinal.ligament.stented.vein.cohort)){
  stent.patient = inguinal.ligament.stented.vein.cohort$record_id[i]
  stented.vein = inguinal.ligament.stented.vein.cohort$Vein[i]
  procedure.number = inguinal.ligament.stented.vein.cohort$Procedure.Number[i]
  # stent brand data by patient, procedure, and Vein
  brand.vein.data = stent.brand.procedure.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stented.vein) %>%
    filter(Procedure.Number == procedure.number) %>%
    filter(!is.na(Brand) & Brand != "") %>%
    select(Brand) %>%
    unique()
  if(nrow(brand.vein.data) > 0){
    if(nrow(brand.vein.data) > 1){
      # Multiple Brands of Stents used to stent Vein
      Stent.Brand[i] = "Multiple.Brands"
    }else{
      Stent.Brand[i] = brand.vein.data$Brand[1]
    }
  }
  # stent diameter data by patient, procedure, and Vein
  diameter.vein.data = stent.diameter.procedure.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stented.vein) %>%
    filter(Procedure.Number == procedure.number) %>%
    filter(!is.na(Diameter.Value)) %>%
    select(Diameter.Value) %>%
    unique()
  if(nrow(diameter.vein.data) > 0){
    if(nrow(diameter.vein.data) > 1){
      # Multiple Diameters of Stents used to stent Vein
      Stent.Diameter[i] = "Multiple.Diameters"
    }else{
      Stent.Diameter[i] = diameter.vein.data$Diameter.Value[1]
    }
  }
  # stent length data by patient, procedure, and Vein
  length.vein.data = stent.length.procedure.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stented.vein) %>%
    filter(Procedure.Number == procedure.number) %>%
    filter(!is.na(Length.Value)) %>%
    select(Length.Value) %>%
    unique()
  if(nrow(length.vein.data) > 0){
    if(nrow(length.vein.data) > 1){
      # Multiple Lengths of Stents used to stent Vein
      Stent.Length[i] = "Multiple.Lengths"
    }else{
      Stent.Length[i] = length.vein.data$Length.Value[1]
    }
  }
}

inguinal.ligament.stented.vein.cohort = cbind.data.frame(inguinal.ligament.stented.vein.cohort, Stent.Brand,
  Stent.Diameter, Stent.Length)