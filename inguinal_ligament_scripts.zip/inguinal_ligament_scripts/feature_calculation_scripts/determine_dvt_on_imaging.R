# determine_dvt_on_imaging.R

# This script determines the DVT on Imaging status of a vein at the time of stent
# placement on conventional venogram.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing DVT on Imaging Data
dvt.imaging.data = gather(dvt.imaging.data, Vein, DVT.Status, -record_id, -Study.Number)

dvt.imaging.data$DVT.Status = as.character(dvt.imaging.data$DVT.Status)

dvt.imaging.data = filter(dvt.imaging.data, !is.na(DVT.Status))

dvt.imaging.data = imaging.accession.date.mapping %>%
  select(record_id, Study.Number, date, Imaging.Study.Modality) %>%
  right_join(dvt.imaging.data, by = c("record_id", "Study.Number"))

DVT.on.Imaging.Status = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

for(i in 1:nrow(inguinal.ligament.stented.vein.cohort)){
  stent.patient = inguinal.ligament.stented.vein.cohort$record_id[i]
  stent.vein = inguinal.ligament.stented.vein.cohort$Vein[i]
  stent.placement.date = inguinal.ligament.stented.vein.cohort$Stent.Placement.Date[i]
  # DVT on Imaging data by Patient and Vein
  dvt.vein.data = dvt.imaging.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stent.vein) %>%
    # Remove non-conventional venography studies
    filter(Imaging.Study.Modality == "Conventional Venography") %>%
    # Consider conventional venogram at time of stent placement
    filter(year(date) == year(stent.placement.date) & month(date) == month(stent.placement.date) 
           & day(date) == day(stent.placement.date))
  if(nrow(dvt.vein.data) > 0){
    DVT.on.Imaging.Status[i] = dvt.vein.data$DVT.Status[1]
  }
}

inguinal.ligament.stented.vein.cohort = cbind.data.frame(inguinal.ligament.stented.vein.cohort,
    DVT.on.Imaging.Status)