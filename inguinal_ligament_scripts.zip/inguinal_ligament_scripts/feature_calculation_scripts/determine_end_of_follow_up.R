# determine_end_of_follow_up.R

# This script calculates the duration of follow-up for each remaining patient in the
# analysis, based on Imaging, Procedure, IR Clinic Visit, Non IR Encounter, and 
# Cancer Registry (Death Date) data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

Follow.Up.Duration = rep(0, times = nrow(first.Stanford.procedure.dataframe))
Last.Imaging.Study.Follow.up = rep(NA, times = nrow(first.Stanford.procedure.dataframe))
Last.Procedure.Follow.up = rep(NA, times = nrow(first.Stanford.procedure.dataframe))
Last.IR.Clinic.Visit.Follow.up = rep(NA, times = nrow(first.Stanford.procedure.dataframe))
Last.Non.IR.Encounter.Follow.up = rep(NA, times = nrow(first.Stanford.procedure.dataframe))

for(i in 1:nrow(first.Stanford.procedure.dataframe)){
  stenting.patient = first.Stanford.procedure.dataframe$record_id[i]
  patient.imaging.data = filter(imaging.accession.date.mapping, record_id == stenting.patient)
  if(nrow(patient.imaging.data) > 0){
    patient.imaging.data = arrange(patient.imaging.data, desc(date))
    Last.Imaging.Study.Follow.up[i] = as.character(patient.imaging.data$date[1])
    # Extent of Imaging Follow-up after first Stanford procedure Date
    imaging.follow.up.span = round(as.numeric(difftime(as.Date(Last.Imaging.Study.Follow.up[i]), 
      first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date[i], units = "days")), digits = 0)
    if(imaging.follow.up.span > Follow.Up.Duration[i]){
      Follow.Up.Duration[i] = imaging.follow.up.span
    }
  }
  patient.procedure.data = filter(procedure.date.data, record_id == stenting.patient)
  if(nrow(patient.procedure.data) > 0){
    patient.procedure.data = arrange(patient.procedure.data, desc(proc_date))
    Last.Procedure.Follow.up[i] = as.character(patient.procedure.data$proc_date[1])
    # Extent of Procedure Follow-up after first Stanford procedure Date
    procedure.follow.up.span = round(as.numeric(difftime(as.Date(Last.Procedure.Follow.up[i]), 
      first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date[i], units = "days")), digits = 0)
    if(procedure.follow.up.span > Follow.Up.Duration[i]){
      Follow.Up.Duration[i] = procedure.follow.up.span
    }
  }
  patient.ir.clinic.visit.data = filter(ir.clinic.visit.practitioner.visit.date.data, record_id == stenting.patient)
  if(nrow(patient.ir.clinic.visit.data) > 0){
    patient.ir.clinic.visit.data = arrange(patient.ir.clinic.visit.data, desc(visitdate))
    Last.IR.Clinic.Visit.Follow.up[i] = as.character(patient.ir.clinic.visit.data$visitdate[1])
    # Extent of IR Clinic Visit Follow-up after first Stanford procedure Date
    ir.clinic.visit.follow.up.span = round(as.numeric(difftime(as.Date(Last.IR.Clinic.Visit.Follow.up[i]), 
      first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date[i], units = "days")), digits = 0)
    if(ir.clinic.visit.follow.up.span > Follow.Up.Duration[i]){
      Follow.Up.Duration[i] = ir.clinic.visit.follow.up.span
    }
  }
  patient.non.ir.encounter.data = filter(non.ir.clinic.dates.data, record_id == stenting.patient)
  if(nrow(patient.non.ir.encounter.data) > 0){
    patient.non.ir.encounter.data = arrange(patient.non.ir.encounter.data, desc(nonir_date))
    Last.Non.IR.Encounter.Follow.up[i] = as.character(patient.non.ir.encounter.data$nonir_date[1])
    # Extent of Non-IR Encounter Follow-up after first Stanford procedure Date
    non.ir.encounter.follow.up.span = round(as.numeric(difftime(as.Date(Last.Non.IR.Encounter.Follow.up[i]), 
      first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date[i], units = "days")), digits = 0)
    if(non.ir.encounter.follow.up.span > Follow.Up.Duration[i]){
      Follow.Up.Duration[i] = non.ir.encounter.follow.up.span
    }
  }
  patient.death.data = filter(demographics.death.data, record_id == stenting.patient)
  if(nrow(patient.death.data) > 0){
    # Span between Cancer registry recorded death date and first Stanford procedure date
    death.follow.up.span = round(as.numeric(difftime(patient.death.data$death_date[1], 
    first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date[i], units = "days")), digits = 0)
    if(death.follow.up.span > Follow.Up.Duration[i]){
      Follow.Up.Duration[i] = death.follow.up.span
    }
  }
}

first.Stanford.procedure.dataframe = cbind.data.frame(first.Stanford.procedure.dataframe,
    Follow.Up.Duration, Last.Imaging.Study.Follow.up, Last.Procedure.Follow.up, 
    Last.IR.Clinic.Visit.Follow.up, Last.Non.IR.Encounter.Follow.up)

first.Stanford.procedure.dataframe = demographics.death.data %>%
  select(record_id, death_date) %>%
  right_join(first.Stanford.procedure.dataframe, by = "record_id")
