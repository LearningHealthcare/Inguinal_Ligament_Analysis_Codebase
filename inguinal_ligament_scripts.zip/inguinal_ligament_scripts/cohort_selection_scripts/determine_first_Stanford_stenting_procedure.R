# determine_first_Stanford_stenting_procedure.R

# This script is responsible for determining the first Stanford stenting procedure
# for the cohort of patients represented in the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

stent.location.procedure.data = stent.location.procedure.data %>%
  gather(Stent.Location, Stent.Value, -record_id, -Procedure.Number) %>%
  filter(!is.na(Stent.Value)) %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Stent.Number = gsub("[^0-9]", "", Stent.Location)) %>%
  mutate(Record.ID.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+"))

Vein = rep("", times = nrow(stent.location.procedure.data))

for(i in 1:nrow(stent.location.procedure.data)){
  # Extract Vein name from Stent Location
  stent.location = stent.location.procedure.data$Stent.Location[i]
  stent.location = unlist(strsplit(stent.location, "_"))
  Vein[i] = stent.location[2]
}

stent.location.procedure.data = cbind.data.frame(stent.location.procedure.data, Vein)

stent.location.procedure.data = select(stent.location.procedure.data, -Stent.Location)

# Combine stent location and stent date data
stent.location.date.procedure.data = left_join(stent.location.procedure.data, procedure.date.data, 
      by = c("record_id", "Procedure.Number"))

# record_ids represented in stent location date procedure dataframe
procedure.record.ids = stent.location.date.procedure.data %>%
  select(record_id) %>%
  unique()

procedure.record.ids = procedure.record.ids[, 1]

first.Stanford.procedure.date = rep("", times = length(procedure.record.ids))

first.Stanford.procedure.number = rep(0, times = length(procedure.record.ids))

for(i in 1:length(procedure.record.ids)){
  procedure.record.id = procedure.record.ids[i]
  # Arrange stent procedures from most prior to most recent
  procedure.record.id.data = stent.location.date.procedure.data %>%
    filter(record_id == procedure.record.id) %>%
    arrange(proc_date)
  first.Stanford.procedure.date[i] = as.character(procedure.record.id.data$proc_date[1])
  first.Stanford.procedure.number[i] = procedure.record.id.data$Procedure.Number[1]
}

first.Stanford.procedure.dataframe = cbind.data.frame(procedure.record.ids, first.Stanford.procedure.number, 
                                                      first.Stanford.procedure.date)

names(first.Stanford.procedure.dataframe) = c("record_id", "Procedure.Number", "First.Stanford.Procedure.Date")

# Convert First Stanford Procedure Date to date-time format
first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date = as.POSIXct(first.Stanford.procedure.dataframe$First.Stanford.Procedure.Date)