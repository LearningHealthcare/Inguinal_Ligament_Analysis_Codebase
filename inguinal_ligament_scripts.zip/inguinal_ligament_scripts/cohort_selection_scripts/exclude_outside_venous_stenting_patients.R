# exclude_outside_venous_stenting_patients.R

# This script is responsible for excluding patients from subsequent analyses
# that had outside stenting (OSH, or non Stanford stenting) prior to their first Stanford procedure date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing OSH venous stenting status data
outside.venous.stenting.status = outside.venous.procedure.medical.history.data %>%
  select(record_id, Outside.Venous.Procedure.1.Venous.Stenting.Status, Outside.Venous.Procedure.2.Venous.Stenting.Status,
         Outside.Venous.Procedure.3.Venous.Stenting.Status, Outside.Venous.Procedure.4.Venous.Stenting.Status,
         Outside.Venous.Procedure.5.Venous.Stenting.Status, Outside.Venous.Procedure.6.Venous.Stenting.Status,
         Outside.Venous.Procedure.7.Venous.Stenting.Status, Outside.Venous.Procedure.8.Venous.Stenting.Status,
         Outside.Venous.Procedure.9.Venous.Stenting.Status, Outside.Venous.Procedure.10.Venous.Stenting.Status) %>%
  gather(Procedure, Status, -record_id) %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Outside.Procedure.Number = gsub("[^0-9]", "", Procedure)) %>%
  filter(Status == "Yes") %>%
  select(-Procedure)

# Dataframe containing OSH venous dates data
outside.venous.procedure.dates = outside.venous.procedure.medical.history.data %>%
  select(record_id, outside_venous_date_1, outside_venous_date_2, outside_venous_date_3, outside_venous_date_4,
         outside_venous_date_5, outside_venous_date_6, outside_venous_date_7, outside_venous_date_8,
         outside_venous_date_9, outside_venous_date_10) %>%
  gather(Procedure, Procedure.Date, -record_id) %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Outside.Procedure.Number = gsub("[^0-9]", "", Procedure)) %>%
  filter(!is.na(Procedure.Date)) %>%
  select(-Procedure)

# Combine OSH venous stenting status and procedure dates data
outside.venous.stenting.dataframe = outside.venous.stenting.status %>%
  left_join(outside.venous.procedure.dates, by = c("record_id", "Outside.Procedure.Number")) %>%
  filter(!is.na(Procedure.Date)) %>%
  arrange(record_id, Procedure.Date)

# Convert Outside Stenting Date to date-time format
outside.venous.stenting.dataframe$Outside.Stenting.Date = as.POSIXct(outside.venous.stenting.dataframe$Procedure.Date)

outside.venous.stenting.dataframe = select(outside.venous.stenting.dataframe, -Procedure.Date)

first.Stanford.procedure.dataframe = first.Stanford.procedure.dataframe %>%
  left_join(outside.venous.stenting.dataframe, by = "record_id") %>%
  # Time between OSH Stenting Date and First Stanford Procedure Date
  mutate(OSH.first.procedure.datetime.difference = round(as.numeric(difftime(Outside.Stenting.Date, 
        First.Stanford.Procedure.Date, units = "days")), digits = 0)) %>%
  # Remove patients with prior OSH stenting
  filter(is.na(OSH.first.procedure.datetime.difference) | OSH.first.procedure.datetime.difference > 0) %>%
  select(record_id, Procedure.Number, First.Stanford.Procedure.Date)
