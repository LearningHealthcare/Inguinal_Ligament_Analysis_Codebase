# identify_thrombotic_complications.R

# This script is responsible for identifying thrombotic complications after the follow-up start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(patency.calculation.code.directory, 'identify_ir_clinic_visit_thrombotic_complications.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_non_ir_encounter_thrombotic_complications.R', sep = '/'))