# calculate_right_leg_patency_status.R

# This script calculates the updated right leg patency status for a series of patients.
# In addition, the script calculates when the patency status from the followup start date is 
# first lost, if applicable.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

patency.rate.dataframe$first.post.start.date.balloon.angioplasty.Right.Leg = as.character(patency.rate.dataframe$first.post.start.date.balloon.angioplasty.Right.Leg)
patency.rate.dataframe$first.post.start.date.stenting.Right.Leg = as.character(patency.rate.dataframe$first.post.start.date.stenting.Right.Leg)
patency.rate.dataframe$first.post.start.date.recanalization.Right.Leg = as.character(patency.rate.dataframe$first.post.start.date.recanalization.Right.Leg)
patency.rate.dataframe$first.post.start.date.thrombectomy.Right.Leg = as.character(patency.rate.dataframe$first.post.start.date.thrombectomy.Right.Leg)
patency.rate.dataframe$first.post.start.date.thrombolysis.Right.Leg = as.character(patency.rate.dataframe$first.post.start.date.thrombolysis.Right.Leg)

primary.patency.right.leg.span = rep(NA, times = nrow(patency.rate.dataframe))
right.leg.primary.patency.loss.date = rep(NA, times = nrow(patency.rate.dataframe))

assisted.primary.patency.right.leg.span = rep(NA, times = nrow(patency.rate.dataframe))
assisted.primary.patency.right.leg.loss.date = rep(NA, times = nrow(patency.rate.dataframe))

for(i in 1:nrow(patency.rate.dataframe)){
  patency.rate.patient.data = patency.rate.dataframe[i, ]
  # Calculate first right leg re-intervention/thrombotic complication after followup start date (if applicable)
  if(!is.na(patency.rate.dataframe$Right.Limb.Status[i])){
    ir.thrombotic.complication.date = patency.rate.patient.data$ir.clinic.visit.first.thrombotic.complication.date[1]
    # Examine first IR Clinic Visit thrombotic complication
    if(!is.na(ir.thrombotic.complication.date)){
      ir.thrombotic.complication.date = as.Date(ir.thrombotic.complication.date)
      ir.thrombotic.complication.span = round(as.numeric(difftime(ir.thrombotic.complication.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > ir.thrombotic.complication.span)){
        primary.patency.right.leg.span[i] = ir.thrombotic.complication.span
        right.leg.primary.patency.loss.date[i] = as.character(ir.thrombotic.complication.date)
        assisted.primary.patency.right.leg.span[i] = ir.thrombotic.complication.span
        assisted.primary.patency.right.leg.loss.date[i] = as.character(ir.thrombotic.complication.date)
      }
    }
    non.ir.thrombotic.complication.date = patency.rate.patient.data$non.ir.clinic.encounter.first.thrombotic.complication.date[1]
    # Examine first non IR encounter thrombotic complication
    if(!is.na(non.ir.thrombotic.complication.date)){
      non.ir.thrombotic.complication.date = as.Date(non.ir.thrombotic.complication.date)
      non.ir.thrombotic.complication.span = round(as.numeric(difftime(non.ir.thrombotic.complication.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > non.ir.thrombotic.complication.span)){
        primary.patency.right.leg.span[i] = non.ir.thrombotic.complication.span
        right.leg.primary.patency.loss.date[i] = as.character(non.ir.thrombotic.complication.date)
        assisted.primary.patency.right.leg.span[i] = non.ir.thrombotic.complication.span
        assisted.primary.patency.right.leg.loss.date[i] = as.character(non.ir.thrombotic.complication.date)
      }
    }
    balloon.angioplasty.right.leg.date = patency.rate.patient.data$first.post.start.date.balloon.angioplasty.Right.Leg[1]
    # Examine balloon angioplasty re-intervention
    if(!is.na(balloon.angioplasty.right.leg.date)){
      balloon.angioplasty.right.leg.date = as.Date(balloon.angioplasty.right.leg.date)
      balloon.angioplasty.span = round(as.numeric(difftime(balloon.angioplasty.right.leg.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > balloon.angioplasty.span)){
        primary.patency.right.leg.span[i] = balloon.angioplasty.span
        right.leg.primary.patency.loss.date[i] = as.character(balloon.angioplasty.right.leg.date)
      }
    }
    stent.right.leg.date = patency.rate.patient.data$first.post.start.date.stenting.Right.Leg[1]
    # Examine stent re-intervention
    if(!is.na(stent.right.leg.date)){
      stent.right.leg.date = as.Date(stent.right.leg.date)
      stent.span = round(as.numeric(difftime(stent.right.leg.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > stent.span)){
        primary.patency.right.leg.span[i] = stent.span
        right.leg.primary.patency.loss.date[i] = as.character(stent.right.leg.date)
      }
    }
    recanalization.right.leg.date = patency.rate.patient.data$first.post.start.date.recanalization.Right.Leg[1]
    # Examine Recanalization re-intervention
    if(!is.na(recanalization.right.leg.date)){
      recanalization.right.leg.date = as.Date(recanalization.right.leg.date)
      recanalization.span = round(as.numeric(difftime(recanalization.right.leg.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > recanalization.span)){
        primary.patency.right.leg.span[i] = recanalization.span
        right.leg.primary.patency.loss.date[i] = as.character(recanalization.right.leg.date)
      }
    }
    thrombectomy.right.leg.date = patency.rate.patient.data$first.post.start.date.thrombectomy.Right.Leg[1]
    # Examine thrombectomy re-intervention
    if(!is.na(thrombectomy.right.leg.date)){
      thrombectomy.right.leg.date = as.Date(thrombectomy.right.leg.date)
      thrombectomy.span = round(as.numeric(difftime(thrombectomy.right.leg.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > thrombectomy.span)){
        primary.patency.right.leg.span[i] = thrombectomy.span
        right.leg.primary.patency.loss.date[i] = as.character(thrombectomy.right.leg.date)
      }
    }
    thrombolysis.right.leg.date = patency.rate.patient.data$first.post.start.date.thrombolysis.Right.Leg[1]
    # Examine thrombolysis re-intervention
    if(!is.na(thrombolysis.right.leg.date)){
      thrombolysis.right.leg.date = as.Date(thrombolysis.right.leg.date)
      thrombolysis.span = round(as.numeric(difftime(thrombolysis.right.leg.date, patency.rate.patient.data$Followup.Start.Date, units = "days")), digits = 0)
      if(is.na(primary.patency.right.leg.span[i]) | (primary.patency.right.leg.span[i] > thrombolysis.span)){
        primary.patency.right.leg.span[i] = thrombolysis.span
        right.leg.primary.patency.loss.date[i] = as.character(thrombolysis.right.leg.date)
      }
    }
  }
}

patency.rate.dataframe = cbind.data.frame(patency.rate.dataframe, primary.patency.right.leg.span, right.leg.primary.patency.loss.date,
  assisted.primary.patency.right.leg.span, assisted.primary.patency.right.leg.loss.date)

patency.rate.dataframe = patency.rate.dataframe %>%
  mutate(Right.Leg.Final.Primary.Patency.Status = ifelse(is.na(primary.patency.right.leg.span), Follow.Start.Left.Leg.Patency.Status,
        "Primary.Patency.Lost")) %>%
  mutate(Right.Leg.Final.Assisted.Primary.Patency.Status = ifelse(is.na(assisted.primary.patency.right.leg.span), 
         "Assisted.Primary.Patency.Not.Lost", "Assisted.Primary.Patency.Lost")) %>%
  mutate(Right.Leg.Final.Secondary.Patency.Status = ifelse(is.na(right.leg.secondary.patency.span), 
         "Secondary.Patency.Not.Lost", "Secondary.Patency.Lost"))