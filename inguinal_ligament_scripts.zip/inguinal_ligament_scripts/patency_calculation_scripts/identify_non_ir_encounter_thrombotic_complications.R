# identify_non_ir_encounter_thrombotic_complications.R

# This script identifies thrombotic complications recognized during Non-IR Encounters
# after the followup start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Non-IR Encounter Thrombotic Complications Data
non.ir.clinic.encounter.thromobotic.complications.data = non.ir.complication.name.data %>%
  select(record_id, Non.IR.Encounter.Number, encounter_thromb_complication_name) %>%
  filter(!is.na(encounter_thromb_complication_name) & encounter_thromb_complication_name != "") %>%
  inner_join(non.ir.complication.status.data, by = c("record_id", "Non.IR.Encounter.Number")) %>%
  # Include major complications only
  filter(encounter_thromb_comp_major_minor == "Major") %>%
  filter(encounter_thromb_complication_name != "Pulmonary embolism" & 
        encounter_thromb_complication_name != "Pulmonary embolism; Portal vein thrombus") %>%
  left_join(non.ir.complication.time.data, by = c("record_id", "Non.IR.Encounter.Number")) %>%
  inner_join(non.ir.clinic.dates.data, by = c("record_id", "Non.IR.Encounter.Number")) %>%
  mutate(Non.IR.Encounter.Date = nonir_date) %>%
  select(-encounter_bleed_complication_time, -encounter_backpain_complication_time, -encounter_other_complication_time,
         -nonir_date, -encounter_bleed_comp_major_minor, -encounter_backpain_comp_major_minor, -encounter_other_comp_major_minor) %>%
  arrange(record_id, Non.IR.Encounter.Date)

non.ir.clinic.encounter.thromobotic.complications.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date) %>%
  left_join(non.ir.clinic.encounter.thromobotic.complications.data, by = "record_id") %>%
  # Calculate span between Non IR encounter date and Follow-up 
  mutate(Non.IR.Encounter.Followup.Span = round(as.numeric(difftime(Non.IR.Encounter.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(Non.IR.Encounter.Followup.Span > 0) %>%
  select(-Followup.Start.Date, -Non.IR.Encounter.Followup.Span)

# patients with non IR Encounter Thrombotic Complications after followup start date
non.ir.clinic.encounter.thrombotic.complications.patients = non.ir.clinic.encounter.thromobotic.complications.data %>%
  select(record_id) %>%
  unique()

non.ir.clinic.encounter.thrombotic.complications.patients = non.ir.clinic.encounter.thrombotic.complications.patients[, 1]

non.ir.clinic.encounter.first.thrombotic.complication.date = rep("", 
  times = length(non.ir.clinic.encounter.thrombotic.complications.patients))

non.ir.clinic.encounter.first.thrombotic.complication.time = rep("", 
  times = length(non.ir.clinic.encounter.thrombotic.complications.patients))

non.ir.clinic.encounter.first.thrombotic.complication.name = rep("",
  times = length(non.ir.clinic.encounter.thrombotic.complications.patients))

for(i in 1:length(non.ir.clinic.encounter.thrombotic.complications.patients)){
  non.ir.thromobotic.complication.patient = non.ir.clinic.encounter.thrombotic.complications.patients[i]
  # Identify first thrombotic complication after followup start date
  non.ir.thrombotic.complication.patient.data = non.ir.clinic.encounter.thromobotic.complications.data %>%
    filter(record_id == non.ir.thromobotic.complication.patient) %>%
    arrange(Non.IR.Encounter.Date)
  non.ir.clinic.encounter.first.thrombotic.complication.date[i] = as.character(non.ir.thrombotic.complication.patient.data$Non.IR.Encounter.Date[1])
  non.ir.clinic.encounter.first.thrombotic.complication.time[i] = non.ir.thrombotic.complication.patient.data$encounter_thromb_complication_time[1]
  non.ir.clinic.encounter.first.thrombotic.complication.name[i] = non.ir.thrombotic.complication.patient.data$encounter_thromb_complication_name[1]
}

first.non.ir.encounter.thrombotic.complication.dataframe = cbind.data.frame(non.ir.clinic.encounter.thrombotic.complications.patients, 
  non.ir.clinic.encounter.first.thrombotic.complication.date, non.ir.clinic.encounter.first.thrombotic.complication.name, 
  non.ir.clinic.encounter.first.thrombotic.complication.time)

names(first.non.ir.encounter.thrombotic.complication.dataframe)[1] = "record_id"

# Convert First Non-IR Encoutner Thrombotic Complication Date to date-time format
first.non.ir.encounter.thrombotic.complication.dataframe$non.ir.clinic.encounter.first.thrombotic.complication.date = as.POSIXct(first.non.ir.encounter.thrombotic.complication.dataframe$non.ir.clinic.encounter.first.thrombotic.complication.date)

patency.rate.dataframe = left_join(patency.rate.dataframe, first.non.ir.encounter.thrombotic.complication.dataframe, by = "record_id")
