# determine_vein_in_imaging_data.R

# This script identifies vein diameters associated with a cohort of veins.
# Vein Diameters consist of both maximum and minimum values, while IVC veins 
# have major and minor axis measurements, with both minimums and maximums.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

vein.diameter.imaging.data = vein.diameter.imaging.data %>%
  gather(Vein.Measurement, Diameter, -record_id, -Study.Number) %>%
  filter(!is.na(Diameter))

Axis = rep(NA, times = nrow(vein.diameter.imaging.data))

Vein = rep(NA, times = nrow(vein.diameter.imaging.data))

Measurement.Type = rep(NA, times = nrow(vein.diameter.imaging.data))

for(i in 1:nrow(vein.diameter.imaging.data)){
  vein.string = vein.diameter.imaging.data$Vein.Measurement[i]
  vein.string = unlist(strsplit(vein.string, "_"))
  # Identify Vein Diameter Measurement Type
  Measurement.Type[i] = vein.string[2]
  if(vein.string[1] == "Infrarenal.IVC.Long" | vein.string[1] == "Infrarenal.IVC.Short" 
     | vein.string[1] == "Suprarenal.IVC.Long" | vein.string[1] == "Suprarenal.IVC.Short"){
    vein.string = vein.string[1]
    vein.string = unlist(strsplit(vein.string, "[.]"))
    Vein[i] = paste(vein.string[1], vein.string[2], sep = ".")
    # Axis of IVC diameter measurement
    Axis[i] = vein.string[3]
  }else{
    # Vein associated with diameter measurment
    Vein[i] = vein.string[1]
  }
}

vein.diameter.imaging.data = cbind.data.frame(vein.diameter.imaging.data,
                                              Vein, Axis, Measurement.Type)

vein.diameter.imaging.data = select(vein.diameter.imaging.data, -Vein.Measurement)

# Combine vein diameter with imaging study date data
vein.diameter.imaging.data = imaging.accession.date.mapping %>%
  select(-Imaging.Study.Laterality) %>%
  right_join(vein.diameter.imaging.data, by = c("record_id", "Study.Number"))