# identify_permanent_occlusion_status.R

# This script calculates whether each patient in a cohort are ultimately "permanently occluded"
# (vein diameter of 0 in treated vein, after both an initial procedure and >= 1 re-intervention with no
# subsequent re-intervention after occluded vein is documented).

# By David Cohn

# Rubin and Hofmann Labs, July 2018

left.leg.secondary.patency.loss.date = rep(NA, times = nrow(patency.rate.dataframe))

right.leg.secondary.patency.loss.date = rep(NA, times = nrow(patency.rate.dataframe))

left.leg.secondary.patency.span = rep(NA, times = nrow(patency.rate.dataframe))

right.leg.secondary.patency.span = rep(NA, times = nrow(patency.rate.dataframe))

patency.rate.dataframe$left.leg.last.patency.procedure.date = as.character(patency.rate.dataframe$left.leg.last.patency.procedure.date)

patency.rate.dataframe$right.leg.last.patency.procedure.date = as.character(patency.rate.dataframe$right.leg.last.patency.procedure.date)

for(i in 1:nrow(patency.rate.dataframe)){
  patient = patency.rate.dataframe$record_id[i]
  if(!is.na(patency.rate.dataframe$Left.Limb.Status[i])){
    left.leg.last.patency.procedure = as.character(patency.rate.dataframe$left.leg.last.patency.procedure.date[i])
    left.leg.followup.start.date = patency.rate.dataframe$Followup.Start.Date[i]
    if(!is.na(left.leg.last.patency.procedure)){
      patient.permanent.occlusion.data = vein.diameter.imaging.data %>%
        filter(record_id == patient) %>%
        filter(Vein %in% left.leg.veins) %>%
        filter(Diameter == 0) %>%
        mutate(Last.Patency.Procedure.Chronic.Occlusion.Span = round(as.numeric(difftime(date, 
               as.Date(left.leg.last.patency.procedure), units = "days")), digits = 0)) %>%
        filter(Last.Patency.Procedure.Chronic.Occlusion.Span >= 0) %>%
        arrange(Last.Patency.Procedure.Chronic.Occlusion.Span)
      if(nrow(patient.permanent.occlusion.data) > 0){
        left.leg.secondary.patency.loss.date[i] = as.character(patient.permanent.occlusion.data$date[1])
        left.leg.secondary.patency.span[i] = round(as.numeric(difftime(patient.permanent.occlusion.data$date[1], 
              left.leg.followup.start.date, units = "days")), digits = 0)
      }
    }
  }
  if(!is.na(patency.rate.dataframe$Right.Limb.Status[i])){
    right.leg.last.patency.procedure = as.character(patency.rate.dataframe$right.leg.last.patency.procedure.date[i])
    right.leg.followup.start.date = patency.rate.dataframe$Followup.Start.Date[i]
    if(!is.na(right.leg.last.patency.procedure)){
      patient.permanent.occlusion.data = vein.diameter.imaging.data %>%
        filter(record_id == patient) %>%
        filter(Vein %in% right.leg.veins) %>%
        filter(Diameter == 0) %>%
        mutate(Last.Patency.Procedure.Chronic.Occlusion.Span = round(as.numeric(difftime(date, 
              as.Date(right.leg.last.patency.procedure), units = "days")), digits = 0)) %>%
        filter(Last.Patency.Procedure.Chronic.Occlusion.Span >= 0) %>%
        arrange(Last.Patency.Procedure.Chronic.Occlusion.Span)
      if(nrow(patient.permanent.occlusion.data) > 0){
        right.leg.secondary.patency.loss.date[i] = as.character(patient.permanent.occlusion.data$date[1])
        right.leg.secondary.patency.span[i] = round(as.numeric(difftime(patient.permanent.occlusion.data$date[1], 
                right.leg.followup.start.date, units = "days")), digits = 0)
      }
    }
  }
}

patency.rate.dataframe = cbind.data.frame(patency.rate.dataframe, left.leg.secondary.patency.loss.date, left.leg.secondary.patency.span,
                                          right.leg.secondary.patency.loss.date, right.leg.secondary.patency.span)
