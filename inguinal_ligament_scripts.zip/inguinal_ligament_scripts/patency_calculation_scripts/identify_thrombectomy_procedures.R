# identify_thrombectomy_procedures.R

# This script identifies thrombectomy procedures that occur after the followup start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# thrombectomy reintervention data
thrombectomy.reintervention.data = thrombectomy.location.procedure.data %>%
  mutate(Record.ID.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  left_join(procedure.date.data, by = c("record_id", "Procedure.Number"))

thrombectomy.reintervention.data$Thrombectomy.Date = thrombectomy.reintervention.data$proc_date

thrombectomy.reintervention.data = select(thrombectomy.reintervention.data, -proc_date)

thrombectomy.reintervention.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date, Left.Limb.Status, Right.Limb.Status) %>%
  left_join(thrombectomy.reintervention.data, by = "record_id") %>%
  # Remove procedures that do not count toward patency calculations
  filter(!(Record.ID.Procedure.Identifier %in% non.patency.procedure.list)) %>%
  # Span between thrombectomy procedure and followup start date
  mutate(Thrombectomy.Followup.Span = round(as.numeric(difftime(Thrombectomy.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(Thrombectomy.Followup.Span > 0) %>%
  select(-Thrombectomy.Followup.Span, -Followup.Start.Date)

# patients with thrombectomy procedures
thrombectomy.patients = thrombectomy.reintervention.data %>%
  select(record_id) %>%
  unique()

thrombectomy.patients = thrombectomy.patients[, 1]

first.post.start.date.thrombectomy.Left.Leg = rep(NA, times = length(thrombectomy.patients))

first.post.start.date.thrombectomy.Right.Leg = rep(NA, times = length(thrombectomy.patients))

last.post.start.date.thrombectomy.Left.Leg = rep(NA, times = length(thrombectomy.patients))

last.post.start.date.thrombectomy.Right.Leg = rep(NA, times = length(thrombectomy.patients))

for(i in 1:length(thrombectomy.patients)){
  thrombectomy.patient = thrombectomy.patients[i]
  thrombectomy.patient.data = thrombectomy.reintervention.data %>%
    filter(record_id == thrombectomy.patient) %>%
    arrange(Thrombectomy.Date)
  # Check if Left Leg is being considered in analysis
  if(!is.na(thrombectomy.patient.data$Left.Limb.Status[1])){
    thrombectomy.patient.left.leg.data = filter(thrombectomy.patient.data, Vein %in% left.leg.veins)
    if(nrow(thrombectomy.patient.left.leg.data) > 0){
      # Identify first left leg thrombectomy procedure
      thrombectomy.patient.left.leg.data = arrange(thrombectomy.patient.left.leg.data, Thrombectomy.Date)
      first.thrombectomy.date = as.character(thrombectomy.patient.left.leg.data$Thrombectomy.Date[1])
      first.post.start.date.thrombectomy.Left.Leg[i] = first.thrombectomy.date
      thrombectomy.patient.left.leg.data = thrombectomy.patient.left.leg.data %>%
        mutate(First.Thrombectomy.Procedure.Span = round(as.numeric(difftime(Thrombectomy.Date, as.Date(first.thrombectomy.date))), digits = 0)) %>%
        filter(First.Thrombectomy.Procedure.Span >= 0) %>%
        arrange(desc(Thrombectomy.Date))
      if(nrow(thrombectomy.patient.left.leg.data) > 0){
        last.post.start.date.thrombectomy.Left.Leg[i] = as.character(thrombectomy.patient.left.leg.data$Thrombectomy.Date[1])
      }
    }
  }
  # Check if Right Leg is being considered in analysis
  if(!is.na(thrombectomy.patient.data$Right.Limb.Status[1])){
    thrombectomy.patient.right.leg.data = filter(thrombectomy.patient.data, Vein %in% right.leg.veins)
    if(nrow(thrombectomy.patient.right.leg.data) > 0){
      # Identify first right leg thrombectomy procedure
      thrombectomy.patient.right.leg.data = arrange(thrombectomy.patient.right.leg.data, Thrombectomy.Date)
      first.thrombectomy.date = as.character(thrombectomy.patient.right.leg.data$Thrombectomy.Date[1])
      first.post.start.date.thrombectomy.Right.Leg[i] = first.thrombectomy.date
      thrombectomy.patient.right.leg.data = thrombectomy.patient.left.leg.data %>%
        mutate(First.Thrombectomy.Procedure.Span = round(as.numeric(difftime(Thrombectomy.Date, as.Date(first.thrombectomy.date))), digits = 0)) %>%
        filter(First.Thrombectomy.Procedure.Span >= 0) %>%
        arrange(desc(Thrombectomy.Date))
      if(nrow(thrombectomy.patient.right.leg.data) > 0){
        last.post.start.date.thrombectomy.Right.Leg[i] = as.character(thrombectomy.patient.right.leg.data$Thrombectomy.Date[1])
      }
    }
  }
}

# Combine left and right leg thrombectomy data
thrombectomy.patients.dataframe = cbind.data.frame(thrombectomy.patients, first.post.start.date.thrombectomy.Left.Leg,
  first.post.start.date.thrombectomy.Right.Leg, last.post.start.date.thrombectomy.Left.Leg, last.post.start.date.thrombectomy.Right.Leg)

names(thrombectomy.patients.dataframe)[1] = "record_id"

patency.rate.dataframe = left_join(patency.rate.dataframe, thrombectomy.patients.dataframe, by = "record_id")
