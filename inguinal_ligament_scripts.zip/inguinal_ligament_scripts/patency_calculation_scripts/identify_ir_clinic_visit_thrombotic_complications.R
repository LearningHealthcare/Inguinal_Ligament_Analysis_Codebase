# identify_ir_clinic_visit_thrombotic_complications.R

# This script identifies thrombotic complications recognized during IR Clinic Visits that occur
# after the follow-up start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# IR Clinic Visit Thrombotic Complications Data
ir.clinic.visit.thromobotic.complications.data = ir.complication.name.data %>%
  select(record_id, IR.Clinic.Visit.Number, thromb_complication_name) %>%
  filter(!is.na(thromb_complication_name) & thromb_complication_name != "") %>%
  inner_join(ir.complication.status.data, by = c("record_id", "IR.Clinic.Visit.Number")) %>%
  # Include Major Thrombotic Complications Only
  filter(thromb_comp_major_minor == "Major") %>%
  filter(thromb_complication_name != "hyperkalemia, ARF" & thromb_complication_name != "pulmonary embolism") %>%
  left_join(ir.complication.time.data, by = c("record_id", "IR.Clinic.Visit.Number")) %>%
  inner_join(ir.clinic.visit.practitioner.visit.date.data, by = c("record_id", "IR.Clinic.Visit.Number")) %>%
  mutate(IR.Clinic.Visit.Date = visitdate) %>%
  select(-backpain_complication_time, -bleed_complication_time, -other_complication_time, -practitioner, 
         -visitdate, -bleed_comp_major_minor, -backpain_comp_major_minor, -other_comp_major_minor) %>%
  arrange(record_id, IR.Clinic.Visit.Date)

ir.clinic.visit.thromobotic.complications.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date) %>%
  left_join(ir.clinic.visit.thromobotic.complications.data, by = "record_id") %>%
  # Span between Clinic Visit Date and Followup Start Date
  mutate(IR.Clinic.Visit.Followup.Span = round(as.numeric(difftime(IR.Clinic.Visit.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(IR.Clinic.Visit.Followup.Span > 0) %>%
  select(-Followup.Start.Date, -IR.Clinic.Visit.Followup.Span)

# patients with thrombotic complications identified during IR Clinic Visits after follow-up start date
ir.clinic.visit.thrombotic.complications.patients = ir.clinic.visit.thromobotic.complications.data %>%
  select(record_id) %>%
  unique()

ir.clinic.visit.thrombotic.complications.patients = ir.clinic.visit.thrombotic.complications.patients[, 1]

ir.clinic.visit.first.thrombotic.complication.date = rep("", 
                                                         times = length(ir.clinic.visit.thrombotic.complications.patients))

ir.clinic.visit.first.thrombotic.complication.time = rep("", 
                                                         times = length(ir.clinic.visit.thrombotic.complications.patients))

ir.clinic.visit.first.thrombotic.complication.name = rep("",
                                                           times = length(ir.clinic.visit.thrombotic.complications.patients))

for(i in 1:length(ir.clinic.visit.thrombotic.complications.patients)){
  ir.thromobotic.complication.patient = ir.clinic.visit.thrombotic.complications.patients[i]
  # Identify first thrombotic complication after followup start date
  ir.thrombotic.complication.patient.data = ir.clinic.visit.thromobotic.complications.data %>%
    filter(record_id == ir.thromobotic.complication.patient) %>%
    arrange(IR.Clinic.Visit.Date)
  ir.clinic.visit.first.thrombotic.complication.date[i] = as.character(ir.thrombotic.complication.patient.data$IR.Clinic.Visit.Date[1])
  ir.clinic.visit.first.thrombotic.complication.time[i] = ir.thrombotic.complication.patient.data$thromb_complication_time[1]
  ir.clinic.visit.first.thrombotic.complication.name[i] = ir.thrombotic.complication.patient.data$thromb_complication_name[1]
}

first.ir.visit.thrombotic.complication.dataframe = cbind.data.frame(ir.clinic.visit.thrombotic.complications.patients, 
                                                           ir.clinic.visit.first.thrombotic.complication.date, ir.clinic.visit.first.thrombotic.complication.name, 
                                                           ir.clinic.visit.first.thrombotic.complication.time)

names(first.ir.visit.thrombotic.complication.dataframe)[1] = "record_id"

# Convert First IR Clinic Vist Thrombotic Complication Date to date-time format
first.ir.visit.thrombotic.complication.dataframe$ir.clinic.visit.first.thrombotic.complication.date = as.POSIXct(first.ir.visit.thrombotic.complication.dataframe$ir.clinic.visit.first.thrombotic.complication.date)

patency.rate.dataframe = left_join(patency.rate.dataframe, first.ir.visit.thrombotic.complication.dataframe, by = "record_id")
